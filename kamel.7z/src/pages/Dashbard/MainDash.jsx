/* eslint-disable no-unused-vars */
import React from "react";

const MainDash = () => {
  return <div>MainDash</div>;
};

export default MainDash;
