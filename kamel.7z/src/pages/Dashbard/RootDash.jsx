/* eslint-disable no-unused-vars */
import React from "react";
import { Outlet } from "react-router-dom";

const RootDash = () => {
  return <div>{/* <Outlet /> */}</div>;
};

export default RootDash;
