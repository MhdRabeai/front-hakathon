/* eslint-disable no-unused-vars */
import React from "react";

export const VideoRoom = () => {
  return <div>VideoRoom</div>;
};
