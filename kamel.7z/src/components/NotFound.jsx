const NotFound = () => {
  return (
    <div className="max-w-[86rem] mx-auto px-4">
      <div className="grid  place-content-center  px-4">
        <h1 className="uppercase tracking-widest text-gray-500">
          404 | Not Found
        </h1>
      </div>
    </div>
  );
};
export default NotFound;
